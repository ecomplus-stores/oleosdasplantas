# Widget User

Storefront plugin with Vue component customer identification
